import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Clock } from "lucide-react";

interface Request {
  id: string;
  status: string;
  request_date: string;
  approved_date: string | null;
  books: {
    title: string;
    author: string;
  };
}

const MyRequests = () => {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) return;

    const { data, error } = await supabase
      .from("borrow_requests")
      .select(`
        *,
        books (title, author)
      `)
      .eq("student_id", user.id)
      .order("request_date", { ascending: false });

    if (error) {
      toast.error("Failed to load requests");
      console.error(error);
    } else {
      setRequests(data as any || []);
    }
    setLoading(false);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      pending: "secondary",
      approved: "default",
      rejected: "destructive",
    };
    
    return (
      <Badge variant={variants[status] || "secondary"}>
        {status}
      </Badge>
    );
  };

  if (loading) {
    return <div className="text-center py-8">Loading your requests...</div>;
  }

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">You haven't requested any books yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {requests.map((request) => (
        <Card key={request.id} className="shadow-card">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold">{request.books.title}</h3>
                  {getStatusBadge(request.status)}
                </div>
                <p className="text-sm text-muted-foreground">by {request.books.author}</p>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>Requested: {new Date(request.request_date).toLocaleDateString()}</p>
                  {request.approved_date && (
                    <p>Approved: {new Date(request.approved_date).toLocaleDateString()}</p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MyRequests;
