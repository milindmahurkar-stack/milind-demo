import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Calendar, User } from "lucide-react";
import { toast } from "sonner";

interface Book {
  id: string;
  title: string;
  author: string;
  description: string | null;
  category: string | null;
  published_year: number | null;
  available_copies: number;
  total_copies: number;
}

interface BookListProps {
  isAdmin: boolean;
}

const BookList = ({ isAdmin }: BookListProps) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    const { data, error } = await supabase
      .from("books")
      .select("*")
      .order("title");

    if (error) {
      toast.error("Failed to load books");
      console.error(error);
    } else {
      setBooks(data || []);
    }
    setLoading(false);
  };

  const handleBorrowRequest = async (bookId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      toast.error("You must be logged in to borrow books");
      return;
    }

    const { error } = await supabase
      .from("borrow_requests")
      .insert({
        student_id: user.id,
        book_id: bookId,
        status: "pending",
      });

    if (error) {
      toast.error("Failed to create request");
      console.error(error);
    } else {
      toast.success("Borrow request submitted successfully!");
    }
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-1/2 mt-2"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (books.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No books available yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {books.map((book) => (
        <Card key={book.id} className="shadow-card hover:shadow-elevated transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <CardTitle className="text-lg">{book.title}</CardTitle>
              <Badge variant={book.available_copies > 0 ? "default" : "secondary"}>
                {book.available_copies}/{book.total_copies}
              </Badge>
            </div>
            <CardDescription className="flex items-center gap-1">
              <User className="h-3 w-3" />
              {book.author}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {book.description && (
              <p className="text-sm text-muted-foreground line-clamp-3">{book.description}</p>
            )}
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              {book.category && (
                <span className="flex items-center gap-1">
                  <BookOpen className="h-3 w-3" />
                  {book.category}
                </span>
              )}
              {book.published_year && (
                <span className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {book.published_year}
                </span>
              )}
            </div>
          </CardContent>
          {!isAdmin && (
            <CardFooter>
              <Button
                className="w-full"
                disabled={book.available_copies === 0}
                onClick={() => handleBorrowRequest(book.id)}
              >
                {book.available_copies > 0 ? "Request to Borrow" : "Not Available"}
              </Button>
            </CardFooter>
          )}
        </Card>
      ))}
    </div>
  );
};

export default BookList;
