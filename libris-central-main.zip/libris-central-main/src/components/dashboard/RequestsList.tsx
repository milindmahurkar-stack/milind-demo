import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Check, X, Clock } from "lucide-react";

interface Request {
  id: string;
  status: string;
  request_date: string;
  books: {
    title: string;
    author: string;
  };
  profiles: {
    full_name: string;
    email: string;
  };
}

const RequestsList = () => {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    const { data, error } = await supabase
      .from("borrow_requests")
      .select(`
        *,
        books (title, author),
        profiles (full_name, email)
      `)
      .order("request_date", { ascending: false });

    if (error) {
      toast.error("Failed to load requests");
      console.error(error);
    } else {
      setRequests(data as any || []);
    }
    setLoading(false);
  };

  const updateRequestStatus = async (requestId: string, status: string) => {
    const { error } = await supabase
      .from("borrow_requests")
      .update({ 
        status,
        approved_date: status === "approved" ? new Date().toISOString() : null
      })
      .eq("id", requestId);

    if (error) {
      toast.error("Failed to update request");
      console.error(error);
    } else {
      toast.success(`Request ${status}!`);
      fetchRequests();
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      pending: "secondary",
      approved: "default",
      rejected: "destructive",
    };
    
    return (
      <Badge variant={variants[status] || "secondary"}>
        {status}
      </Badge>
    );
  };

  if (loading) {
    return <div className="text-center py-8">Loading requests...</div>;
  }

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No borrow requests yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {requests.map((request) => (
        <Card key={request.id} className="shadow-card">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold">{request.books.title}</h3>
                  {getStatusBadge(request.status)}
                </div>
                <p className="text-sm text-muted-foreground">by {request.books.author}</p>
                <div className="text-sm">
                  <p className="font-medium">{request.profiles.full_name}</p>
                  <p className="text-muted-foreground">{request.profiles.email}</p>
                </div>
                <p className="text-xs text-muted-foreground">
                  Requested: {new Date(request.request_date).toLocaleDateString()}
                </p>
              </div>
              {request.status === "pending" && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => updateRequestStatus(request.id, "approved")}
                  >
                    <Check className="h-4 w-4 mr-1" />
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => updateRequestStatus(request.id, "rejected")}
                  >
                    <X className="h-4 w-4 mr-1" />
                    Reject
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default RequestsList;
